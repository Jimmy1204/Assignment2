import java.io.File;
import java.io.FileOutputStream;

import java.io.PrintStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
public class Main2014302580316{
	public static void main(String[] args)
	{
	String url="http://staff.whu.edu.cn/show.jsp?lang=cn&n=Cai%20Jie";
	try{
		//����һ��txt�ļ�
		FileOutputStream teacherCrawler = new FileOutputStream(new File("D:\\Exper\\�̽�.txt"));
		PrintStream t = new PrintStream(teacherCrawler);
		//��Jsoup��ȡ��������
		Document doc = Jsoup.connect(url).timeout(600000000).get();
		Elements ele0 = doc.getElementsByTag("h3");
		Elements ele1 = doc.getElementsByTag("p");
		//Elements ele2 = doc.getElementsByTag("br");
		String name=ele0.get(0).text();
		String summary= ele1.get(0).text();
		//String synopsis = ele2.get(0).text();
		//������
		t.println(name);
	    String[] strarray=summary.split(" "); 
	    for (int i = 0; i < strarray.length; i++) 
	         t.println(strarray[i]); 
		//t.println(synopsis);
	    t.println();
	    t.println();
		t.println("���������ʽ��ȡ�绰������:");//���������ʽ��ȡ�绰������
		String regex1 = "\\d{3}-\\d{8}\\��.*\\d{8}";
		String regex2 = "[a-z]+@[a-z]+\\.[a-z]+\\.[a-z]+\\;.*[a-z]+@[a-z]+\\.[a-z]+";
		Matcher matcher1 = Pattern.compile(regex1).matcher(summary);
		if(matcher1.find()){
			t.println("��ϵ��ʽ��"+matcher1.group(0));
		}
		Matcher matcher2 = Pattern.compile(regex2).matcher(summary);
		if(matcher2.find()){
			t.println("���䣺 "+matcher2.group(0));
		}
		t.close();
	}catch(Exception e){
		e.printStackTrace();
	}
	}
}
